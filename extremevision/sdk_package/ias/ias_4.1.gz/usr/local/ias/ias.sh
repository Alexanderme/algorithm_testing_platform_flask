#! /bin/bash
source /etc/profile

cd /usr/local/ias
./ias --conf local_conf.json 
