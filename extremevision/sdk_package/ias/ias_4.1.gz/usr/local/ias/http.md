# 目录
* [简介](#简介)
* [算法分析](#算法分析)
	* [图片分析](##图片分析)
	* [视频分析](##小视频分析)
	* [视频分析2](##小视频分析--仅送入视频文件地址)
* [参数设置](#参数设置) 
	* [运行参数设置](##运行参数设置)
	* [算法参数设置](##算法参数设置)
* [状态查询](#状态查询)
	* [服务状态查询](##服务状态查询)
	* [qps信息查询](##qps信息查询)
* [授权服务](#授权服务)
	* [获取参考码](##获取参考码)
	* [修改授权信息](##修改授权信息)
	* [获取授权信息](##获取授权信息)
	* [清除授权信息](##清除授权信息)
* [初始图片](#初始图片)
	* [增改初始图片](##增改初始图片)
	* [删除初始图片](##删除初始图片)
* [删除检测器实例](#删除检测器实例)
 	
# 简介
* 本地配置文件`local_conf.json`：`serverMode`选项设置为`http`或`ice & http`，默认启用ice及http服务

* http服务端口有本地配置文件`local_conf.json`：`httpPort`选项设置，默认为80

# 算法分析
## 图片分析
提供基于图片为输入源的算法分析
	 
* 请求方式1--url中带参
	* 路径`/api/analysisImage`，`POST`方法
	* url地址带`filename`,`args`两个参数，需要用url_encode编码，均为可选参数
 	* 请求body为图片原始数据
 	* 示例: 
 `http://192.168.1.1.100:/api/analysisImage?filename=test.jpg&args=POLYGON((0.001 0.001, 0.001 0.999, 0.999 0.999, 0.999 0.001))` 

* 请求方式2--表单
	* 路径`/api/analysisImage`，`POST`方法
 	* 请求body为form-data，例如`Content-Type: multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW`
 	* 示例：

		|  属性名 |        属性值    | 属性类型 | 是否必选参数 |
		| :----  | :---------------------------------: | :--: | :--: |
		| args   |   POLYGON((0.001 0.001, 0.001 0.999, 0.999 0.999, 0.999 0.001)) | text | 否 |
		| image  |   test.jpg                                                      | file | 是 |

* 返回
 * 200，返回json格式数据，`Content-Type:application/json`
 * 成功，示例
 	
			{
				"code": 0，
				"result": {算法输出的json数据}，
				"buffer": "算法输出的图片数据（bas64编码)"
			}

		* code:返回值，0表示成功，其它表示失败
		* result:算法输出的json数据
		* buffer:算法输出的图片数据，base64编码，图片格式与输入图片格式相同，可选参数
		* 是否返回`result`或`buffer`，由本地配置文件`local_conf.json`：`returnValue`选项配置，默认只返回result

	* 失败，示例
 	
			{
				"code": -1，
				"result": "parameter error"
			}
			或
			{
				"code": -2，
				"result": {"err_code":-1,"err_msg":"parameter error"}
			}

		* code:错误号
		* result:错误信息
		  
	**备注:**请求返回失败时，所有服务均是该格式

## 小视频分析
提供基于小视频为输入源的算法分析

* 请求方式1--url中带参
	* 路径`/api/analysisVideo`，`POST`方法
	* url地址带`filename`，`args`两个参数，需要用url_encode编码，其中args为可选参数
 	* 请求body为小视频原始数据
 	* 示例: `http://192.168.1.1.100:/api/analysisVideo?filename=test.mp4&args=POLYGON((0.001 0.001, 0.001 0.999, 0.999 0.999, 0.999 0.001))`

* 请求方式2--表单
	* 路径`/api/analysisVideo`，`POST`方法
 	* 请求body为form-data，例如`Content-Type: multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW`
 	* 示例：

		|  属性名 |        属性值    | 属性类型 | 是否必选参数 |
		| :----  | :---------------------------------: | :--: | :--: |
		| args   |   POLYGON((0.001 0.001, 0.001 0.999, 0.999 0.999, 0.999 0.001)) | text | 否 |
		| video  |   test.mp4                                                      | file | 是 |

* 返回
 * 200，返回json格式数据，`Content-Type:application/json`
 * 成功，示例
 	
			{
				"code": 0，
				"result": {算法输出的json数据}，
				"buffer": "算法输出的视频数据（bas64编码)"
			}
	
		* code:返回值，0表示成功，其它表示失败
		* result:算法输出的json数据；其它则表示错误信息；可选参数  
		* buffer:算法输出的视频数据，base64编码，视频格式统一为mp4（x264编码），可选参数
	  	* 是否返回`result`或`buffer`，由本地配置文件`local_conf.json`：`returnValue`选项配置，默认只返回result

## 小视频分析--仅送入视频文件地址
提供基于小视频为输入源的算法分析，仅需要提供视频输入源url地址

* 请求方式1--url中带参
	* 路径`/api/analysisVideoUrl`，`GET`方法
	* url地址带`videoUrl`，`args`两个参数，需要用url_encode编码，videoUrl表示视频文件地址，其中args为可选参数
 	* 示例: `http://192.168.1.1.100:/api/analysisVideoUrl?videoUrl=http://192.168.1.10/record/test.mp4&args=POLYGON((0.001 0.001, 0.001 0.999, 0.999 0.999, 0.999 0.001))`

* 请求方式2--表单
	* 路径`/api/analysisVideoUrl`，`POST`方法
 	* 请求body为form-data，例如`Content-Type: multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW`
 	* 示例：
 	
		|  属性名 |        属性值    | 属性类型 | 是否必选参数 |
		| :----  | :---------------------------------: | :--: | :--: |
		| args   |   POLYGON((0.001 0.001, 0.001 0.999, 0.999 0.999, 0.999 0.001)) | text | 否 |
		| videoUrl |  http://192.168.1.10/record/test.mp4     | text | 是 |

* 返回
 * 200，返回json格式数据，`Content-Type:application/json`
 * 成功，示例
 	
			{
				"code": 0，
				"result": {算法输出的json数据}，
				"buffer": "算法输出的视频数据（bas64编码)"
			}
	
		* code:返回值，0表示成功，其它表示失败
		* result:算法输出的json数据；其它则表示错误信息；可选参数  
		* buffer:算法输出的视频数据，base64编码，视频格式统一为mp4（x264编码），可选参数
	  	* 是否返回`result`或`buffer`，由本地配置文件`local_conf.json`：`returnValue`选项，默认只返回result

# 参数设置
## 运行参数设置
设置运行参数并立即生效

* 请求
	* 路径`/api/config`，`POST`方法
	* 请求body为json数据
	* 示例

			{
    			"workMode": "cidPredictor",
    			"returnValue": "json & buffer"
			}

		* workMode: 工作模式，提供`simplePredictor`,`cidPredictor`,默认`simplePredictor`
  			1. simplePredictor:仅开启一个检测器实例，该实例支持不同场景的分析；
  			2. cidPredictor:不同的场景需要创建不同的实例来分析，其中cid是场景唯一标识；
		* returnValue:算法返回内容选择，提供`json`,`buffer`,`json & buffer`,默认`json`
  			1. json:只返回json数据；
  			2. buffer:只返回图片或视频数据；
  			3. json & buffer:同时返回json和图片或视频数据；

* 返回
 * 200，返回json格式数据，`Content-Type:application/json`
 * 成功，示例
 	
			{
				"code": 0,
				"result": {"err_code":0,"err_msg":"succeed"}
			}

## 算法参数设置
设置算法配置参数并立即生效

* 请求
	* 路径`/api/algoConfig`，`POST`方法
	* 请求body为json数据，每个算法配置参数可能有所不同，由具体算法为准。
	* 示例

			算法基本配置参数如下
			{
	    		"draw_roi_area":1,
			    "draw_result":1,
	    		"show_result":0,
	    		"gpu_id":0,
	    		"threshold_value":0.5
			}	

		* draw_roi_area:是否绘制感兴趣区域，默认为1
		* draw_result:是否绘制检测结果信息，默认为1
		* show_result:实时显示算法分析图片，默认为0
		* gpu_id:gpu序号，仅对gpu算法有效，默认为0
		* threshold_value:阈值，默认为0.5

* 返回
 * 200，返回json格式数据，`Content-Type:application/json`
 * 成功，示例
 	
			{
				"code": 0,
				"result": {"err_code":0,"err_msg":"succeed"}
			}

# 状态查询
## 服务状态查询
获取ias当前运行状态信息

* 请求
	* 路径`/api/status`，`GET`方法，无参
* 返回
 * 200，返回json格式数据，`Content-Type:application/json`
 * 成功，示例
 	
			{
			    "code": 0,
			    "result": {
			        "whether_authorized": true,
			        "license_data": {
			            "license": "b52f92d8ad261f16e8cafe2a2f6f9589d2f8c77533b92c0f644cf1058557e52a128fe369318f3af5bf6bf229f70bf48820df293dc7dbaf5431e02963e5e3b942febe6ca45de5bee2c1080d91467cdcedfa55555e47bc4955ac3d4e2cbdf6312ec0831a26f1d100f1921576a195aa1666a078ccf6515b40b4060cc08369485532",
			            "version": 7
			        },
			        "run_config": {
			            "workMode": "simplePredictor",
			            "returnValue": "json & buffer"
			        },
			        "whether_created_predictor": false,
			        "predictor_size": 0
			    }
			}

		* code:返回值，0表示成功，其它表示失败
		* whether_authorized:是否授权，通过授权才有license_data信息
		* license_data:授权的相关信息，是个json对象
		* run_config:运行参数，是个json对象，详见`README.md`:`运行参数`
		* whether_created_predictor:是否创建了检测器实例，没触发调用时为0，创建成功为1，创建失败为-1
		* predictor_size:检测器实例数

		**备注**

		* 存活判断:通信线程即工作线程，函数有正常返回即可判定是活的
		* 就绪判断:在授权通过的基础上，再判断(whether_created_predictor != -1)
		* 若(whether_created_predictor == -1 && predictor_size > 0)，表示有部分检测器创建失败，用在`cidPredictor`模式下

## qps信息查询
获取qps相关信息，包括授权中配置的qps，及实际运行的qps（一秒内可处理的帧数）

* 请求
	* 路径`/api/qpsInfo`，`GET`方法，无参
* 返回
 * 200，返回json格式数据，`Content-Type:application/json`
 * 成功，示例
			
			{
			    "code": 0,
			    "result": {
			        "auth_qps": 0,
			        "real_qps": 143.32
			    }
			}
	
		* code:返回值，0表示成功，其它表示失败
		* auth_qps:授权时的qps，没有授权为-1，授权无qps为0，其它为授权的qps值
		* real_qps:实际部署时qps值，动态计算取得（最近10次实际qps的平均值），没跑过算法时为0.00

# 授权服务
* 请求
	* 路径`/api/license`，`POST`方法
	* 请求body为json数据，提供获取参考码，修改授权信息，获取授权信息，清除授权信息四个功能 
* 返回
 * 200，返回json格式数据，`Content-Type:application/json`

## 获取参考码
* 请求
 * 示例

			｛
				"function": "get_reference",
				"isNetworking": 0
			｝

		* function:固定为`get_reference`
		* isNetworking:是否请求联网校验的参考码，1表示是，其它表示否，默认否，可选参数 
	
* 返回
 * 成功，示例 

			{
				"code": 0,
				"result": {
					"version": 7,
					"reference": "4ecf97189dfb9d94df43d9d14fe754ebf2707c614a50a09d5eed8ea953656695",
					"disk_serial": "S3YLNX0K533123P",
					"mac": "02:42:ac:11:00:0d"
				}
			}

		* code:返回值，0表示成功，其它表示失败
		* result:表示返回的参考码相关信息，其中
			* version:版本号
			* reference:参考码
			* 其它信息（版本不同也有所不同）

## 修改授权信息
* 请求
 * 示例

			{
				"function": "update_license",
				"version": 7,
				"license": "b52f92d8ad261f16e8cafe2a2f6f9589d2f8c77533b92c0f644cf1058557e52a128fe369318f3af5bf6bf229f70bf48820df293dc7dbaf5431e02963e5e3b942febe6ca45de5bee2c1080d91467cdcedfa55555e47bc4955ac3d4e2cbdf6312ec0831a26f1d100f1921576a195aa1666a078ccf6515b40b4060cc08369485532",
				"activation": "RDVG4RDVGFPC99993EA19F8334F667714CC5168D39BC3B0B052C2961F506AAAA"
			}

		* function:固定为`update_license`
		* license:授权码
		* url:联网校验服务器地址(http服务)，可选参数
		* activation:激活码，可选参数
		* timestamp:过期时间，可选参数
		* qps:最大请求量，可选参数
		* version:版本号
	
* 返回
 * 成功，示例 

			{
				"code": 0,
				"result": {"err_code":0,"err_msg":"succeed"}
			}

## 获取授权信息
* 请求
 * 示例

			｛
				"function": "query_license"
			｝

			* function:固定为`query_license`
	
* 返回
 * 成功，示例 

			{
				"code": 0,
				"result": {
					"license": "b52f92d8ad261f16e8cafe2a2f6f9589d2f8c77533b92c0f644cf1058557e52a128fe369318f3af5bf6bf229f70bf48820df293dc7dbaf5431e02963e5e3b942febe6ca45de5bee2c1080d91467cdcedfa55555e47bc4955ac3d4e2cbdf6312ec0831a26f1d100f1921576a195aa1666a078ccf6515b40b4060cc08369485532",
					"activation": "RDVG4RDVGFPC99993EA19F8334F667714CC5168D39BC3B0B052C2961F506AAAA",
					"version": 7
				}
			}

		* code:返回值，0表示成功，其它表示失败
		* result:授权信息 
			* license:授权码
			* activation:激活码
			* version:版本号

## 清除授权信息
* 请求
 * 示例

			{
				"function": "update_license"
			}

			* function:固定为`update_license`
			* 无license相关信息
	
* 返回
 * 成功，示例 

			{
				"code": 0,
				"result": {"err_code":0,"err_msg":"succeed"}
			}

# 初始图片
* 有些算法工作时需要预先送入场景初始图片，用于分析对比，例如消防通道检测算法
* 实现方案:给每个场景(cid)提供一张初始图片(jpg)，并存放在`/usr/local/ev_sdk/contrastdata`目录，调用算法的创建检测器方法时，会装载该目录下所有cid命名的jpg文件列表
* 为给上层提供增改、删初始图片的功能，ias提供`updateInitImage`,`deleteInitImage`两个方法

## 增改初始图片
* 请求方式1
	* 路径`/api/updateInitImage`，`POST`方法
	* url地址带`cid`,`filename`两个参数，需要用url_encode编码
 	* 请求body为初始图片原始数据
 	* 示例: `http://192.168.1.1.100:/api/updateInitImage?cid=123456&filename=test.jpg`

* 请求方式2--表单
	* 路径`/api/updateInitImage`，`POST`方法
 	* 请求body为form-data，例如`Content-Type: multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW`
 	* 示例：

		|  属性名 |        属性值    | 属性类型 | 是否必选参数 |
		| :----  | :---------------------------------: | :--: | :--: |
		| cid   |   123456 | text | 是 |
		| image  |   test.jpg   | file | 是 |

* 返回
	* 200，返回json格式数据，`Content-Type:application/json`
	* 成功，示例

			{
				"code": 0,
				"result": {"err_code":0,"err_msg":"succeed"}
			}

## 删除初始图片
* 请求
	* 路径`/api/deleteInitImage`，`DELETE`方法
	* url地址带`cid`参数，需要用url_encode编码，其中`cid=delete`表示删除全部初始图片
 	* 示例: `http://192.168.1.1.100:/api/deleteInitImage?cid=123456`

* 返回
	* 200，返回json格式数据，`Content-Type:application/json`
	* 成功，示例
 	
			{
				"code": 0,
				"result": {"err_code":0,"err_msg":"succeed"}
			}

# 删除检测器实例
该方法仅在`cidPredictor`工作模式下有效，用于删除指定cid的检测器实例，以节省有限的硬件资源，例如内存及gpu内存

* 请求
	* 路径`/api/deletePredictor`，`DELETE`方法
	* url地址带`cid`参数，需要用url_encode编码，其中`cid=delete`表示删除全部检测器实例
 	* 示例: `http://192.168.1.1.100:/api/deletePredictor?cid=123456`

* 返回
	* 200，返回json格式数据，`Content-Type:application/json`
	* 成功，示例

			{
				"code": 0,
				"result": {"err_code":0,"err_msg":"0"}
			}

---