# 目录
* [简介](#简介)
* [编译](#编译)
* [安装](#安装)
* [本地配置文件](#本地配置文件)
* [运行参数格式](#运行参数格式)
* [运维](#运维)
* [ice服务](#ice服务)
* [http服务](#http服务)

# 简介
* 基于ev_sdk:v2.0标准，提供基于图片及视频文件为输入源的算法分析服务
* ias同时支持ice、http两种rpc请求服务
* 软件最终以安装包的形式发布，工作目录`/usr/local/ias`

# 编译

	源码目录结构如下
    ├── README.md               # 本帮助文档
    ├── ready.sh                # 准备脚本
    ├── bin                     # 待安装文件、打包脚本、安装脚本
    ├── doc                     # 相关文档，例如：http协议说明文档
    ├── ice                     # ice文件
    ├── license                 # ev_license依赖库
    ├── src                     # ias源码
    ├── test                    # testIas源码
    
### ias编译
* 拉取源码后，进入源码目录，运行准备脚本`./ready.sh`
* 运行命令`cd src && ./compile`进行编译，生成目标文件ias，同时会自动复制到`bin/usr/local/ias`目录
* 运行`./ias`会输出使用帮助

### testIas编译
* 运行命令`cd test && ./compile`进行编译，生成目标文件testIas，同时会自动复制到`bin/usr/local/ias`目录
* 运行`./testIas`会输出使用帮助

### 安装包
* 运行命令`cd bin && ./package`进行安装包，生成tar包文件，例如 **ias_v4.0.tar.gz**
* tar包文件名中包括版本信息，版本信息在`./src/server.h`文件中，例如 **#define IAS_VERSION  "version:v4.0"**

# 安装
### 1.运行环境
* 除ev_sdk的运行环境外，需要增加`libevent`，请运维打包境像前增加；
* `libevent`安装，例如:  `git clone https://github.com/libevent/libevent.git && cd libevent && ./autogen.sh && ./configure && make -j && make install && ldconfig`

 **备注**：4.20版本后（含），可以不用安装`libevent`库，已把`libevent`运行库打进了ias安装包

### 2.安装
* 安装包存放在`./bin`目录下，文件名包括版本号
* 运行命令，例如 `cd bin && ./install ias_v4.0.tar.gz`，会自动安装在`/usr/local/ias`目录下
* 安装完成后，会自动启动服务，运行命令`pidof ias`会输出服务的进程id
 
### 目录结构如下

    安装目录:/usr/local/ias
    ├── README.md               # 本帮助文档，markdown格式
    ├── README.html             # 本帮助文档，html格式
    ├── ice.md                  # ice服务帮助文档，markdown格式
    ├── ice.html                # ice服务帮助文档，html格式
    ├── http.md                 # http服务帮助文档，markdown格式
    ├── http.html               # http服务帮助文档，html格式
    ├── ae.ice                  # ice服务，ice接口文件
    ├── core_dump.log           # ias异常退出时生成的core_dump文件
    ├── config.server           # ice服务配置文件
    ├── local_conf.json         # 本地配置文件，安装后有默认配置
    ├── run_conf.json           # 运行参数，安装后有默认配置
    ├── license_conf.json       # 授权文件，只有授权通过才存在该文件
    ├── ias                     # 服务程序 
    ├── ias.sh                  # 服务程序启动脚本，内部调用ias
    ├── ias_start.sh            # 服务程序高级启动脚本，内部调用ias.sh
    ├── ias_start_container.sh  # 服务程序高级启动脚本，用于容器启动时调用
    ├── ias_stop.sh             # 服务程序停止脚本    
    ├── ev_codec                # 字符串混编及常量字符串硬编码工具，直接运行会输出帮助
    ├── ev_license              # license工具
    ├── testIas                 # ice服务测试工具，以下七个是测试样例文件
    ├── config_simplePredictor.sample               # config接口，simplePredictor工作模式
    ├── config_cidPredictor.sample                  # config接口，cidPredictor工作模式
    ├── algo_config.sample                          # algoConfig接口，更改算法配置参数
    ├── license_get_reference.sample                # license接口，获取参考码
    ├── license_query_license.sample                # license接口，查询授权信息
    ├── license_update_license.sample               # license接口，修改或清除授权信息
    ├── updateInitImage.sample                      # updateInitImage接口，增加静态初始图片
    ├── ias_data -> /data/${container_id}/ias_data  # 软链接目录，指向docker宿主机
        ├── log                 # glog日志目录
        └── image               # 图片分析临时目录
        └── video               # 视频分析临时目录
    ├── libevent                # libevent库目录，用于实现htpp服务
    └── ...                     # 其它更多文件
	
# 本地配置文件
local_conf.json示例

	{
		"serverMode": "ice & http",
		"httpPort": 80,
		"localConf": "local_conf.json",
		"runConf": "run_conf.json",
		"licenseConf": "license_conf.json",
		"configServer": "config.server",
		"logPath": "/usr/local/ias/ias_data/log/info",
		"imagePath": "/usr/local/ias/ias_data/image",
		"videoPath": "/usr/local/ias/ias_data/video",
		"initImagePath": "/usr/local/ev_sdk/contrastdata"
		"algoConf": "/usr/local/ev_sdk/model/algo_config.json"
	}
 
* serverMode:服务模式，支持`ice`、`http`、`ice & http`，默认开启ice和http服务;
* httpPort:http-server服务端口号，默认80;
* localConf：本地配置文件名;
* runConf:运行参数文件名;
* licenseConf:授权文件名;
* configServer:ice服务器配置文件名;
* logPath:glog日志目录，包括文件名;
* imagePath:图片临时存放目录;
* videoPath:视频临时存放目录;
* initImagePath:静态初始图片存放目录;
* algoConf:算法参数文件存放目录;
    
# 运行参数格式
平台通过ias提供的ice服务接口功能下发，成功后会保存到文件，例如 `run_conf.json`

	{
		"workMode": "simplePredictor",
		"returnValue": "json"
	}

* workMode: 工作模式，提供`simplePredictor`、`cidPredictor`，默认`simplePredictor`
  1. simplePredictor：仅开启一个检测器实例，该实例支持不同场景的分析；
  2. cidPredictor：不同的场景需要创建不同的实例来分析，其中cid是场景唯一标识；
* returnValue:算法返回内容选择，提供`json`、`buffer`、`json & buffer`，默认`json`
  1. json:只返回json数据；
  2. buffer:只返回图片或视频数据；
  3. json & buffer:同时返回json和图片或视频数据；

# 运维
### 启停服务
发布软件已做软链接，实现在任意目录下启停服务，例如 
 
 `ln -s /usr/local/ias/ias_start.sh /usr/bin/ias_start`

 `ln -s /usr/local/ias/ias_stop.sh /usr/bin/ias_stop`
 
 --启动:

 `ias_start`

 --停止:

 `ias_stop`

 --查询:
 
 `ps -ef | grep ias`
 
 或

 `pidof ias`

### 运行日志查询
 `cd /usr/local/ias/ias_data && tail -f log/ias.INFO`

### 清除glog日志
清除glog日志脚本`/usr/local/ias/ias_log_delete.sh`，配置到定时任务即可。

# ice服务
详见`doc/ice.md`文件

# http服务
详见`doc/http.md`文件

---
