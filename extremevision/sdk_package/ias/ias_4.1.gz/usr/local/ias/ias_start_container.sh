#!/bin/bash

#脚本说明
# 功能:用于启动ias,成功返回0,其它返回非0,无参数.

ias_path="/usr/local/ias/ias.sh"
ias_data_path="/usr/local/ias/ias_data"

# 建立软件链接目录，并生成相关子目录
#   目标目录${data_path},例如:/data/0964ee64b0be/ias_data,不存在时会创建
#   软目录${ias_data_path},链接到${data_path},例如:/usr/local/ias/ias_data,链接到/data/0964ee64b0be/ias_data
#     /usr/local/ias/ias_data/log
#     /usr/local/ias/ias_data/image
#     /usr/local/ias/ias_data/video

if [[ ! -d ${ias_data_path} ]]; then
	echo "${ias_data_path} does not exist, ln -s ..."

	data_path="/data"
	contain_id=$(cat /proc/1/cpuset | cut -c9-)
	if [ -z "${contain_id}" ]; then
		echo "get contain_id failed."
		exit -1
	fi	
	
	if [ ${#contain_id} -lt 12 ]; then
		echo "contain_id length < 12, invalid."
		exit -1
	fi
	contain_id=${contain_id:0:12}
	data_path="${data_path}/${contain_id}/ias_data"
	
	# for example: /data/0964ee64b0be/ias_data
	if [[ ! -d ${data_path} ]]; then	
		echo "${data_path} does not exist, mkdir -p ..."
		mkdir -p ${data_path}
		ret=$?
		if [[ ${ret} -ne 0 ]]; then
			echo "mkdir -p ${data_path}, failed."
			exit -1
		fi
	fi

	# for example: ln -s ${ias_data_path} /data/0964ee64b0be/ias_data
	ln -s ${data_path} ${ias_data_path}
	ret=$?
	if [[ ${ret} -ne 0 ]]; then
		echo "ln -s ${data_path} ${ias_data_path}, failed."
		exit -1
	fi
	
	# for example: ${ias_data_path}/video
	video_path="${ias_data_path}/video"
	if [[ ! -d ${video_path} ]]; then	
		echo "${video_path} does not exist, mkdir ..."
		mkdir ${video_path}
		ret=$?
		if [[ ${ret} -ne 0 ]]; then
			echo "mkdir ${video_path}, failed."
			exit -1
		fi
	fi

	# for example: ${ias_data_path}/image
	pic_path="${ias_data_path}/image"
	if [[ ! -d ${pic_path} ]]; then	
		echo "${pic_path} does not exist, mkdir ..."
		mkdir ${pic_path}
		ret=$?
		if [[ ${ret} -ne 0 ]]; then
			echo "mkdir ${pic_path}, failed."
			exit -1
		fi
	fi
	
	# for example: ${ias_data_path}/log
	log_path="${ias_data_path}/log"
	if [[ ! -d ${log_path} ]]; then	
		echo "${log_path} does not exist, mkdir ..."
		mkdir ${log_path}
		ret=$?
		if [[ ${ret} -ne 0 ]]; then
			echo "mkdir ${log_path}, failed."
			exit -1
		fi
	fi
fi 

# 服务是否启动
pids=$(pidof ias)
if [ ! -z "${pids}" ]; then
	echo "ias already started, ${pids}"
	echo "please stop first."	
	exit -1
fi

# 启动
${ias_path}

while true
do
   sleep 5
   pids=$(pidof ias)
   if [ -z "$pids" ]; then
      ${ias_path}
   fi
done

exit 0
