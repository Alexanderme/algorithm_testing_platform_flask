# 目录
* [简介](#简介)
* [ice文件](#ice文件)
* [算法分析](#算法分析)
	* [图片分析](##图片分析)
	* [视频分析](##小视频分析)
	* [视频分析2](##小视频分析--仅送入视频文件地址)
* [参数设置](#参数设置) 
	* [运行参数设置](##运行参数设置)
	* [算法参数设置](##算法参数设置)
* [状态查询](#状态查询)
	* [服务状态查询](##服务状态查询)
	* [qps信息查询](##qps信息查询)
* [授权服务](#授权服务)
	* [获取参考码](##获取参考码)
	* [修改授权信息](##修改授权信息)
	* [获取授权信息](##获取授权信息)
	* [清除授权信息](##清除授权信息)
* [初始图片](#初始图片)
	* [增改初始图片](##增改初始图片)
	* [删除初始图片](##删除初始图片)
* [删除检测器实例](#删除检测器实例)
* [测试工具](#测试工具)
 	
# 简介
* ias默认会开启ice服务，以便响应上层的相关请求，详细配置请参考安装目录下`config.server`文件

* ice服务唯一字符串标识为`IasServer`，默认端口为`10000`

* 安装目录下`ae.ice`是ice文件

* 安装目录下`testIas`是测试工具，直接运行会输出使用帮助

* 源码目录下`test/testIas.cpp`是调用示例 

# ice文件
ae.ice

	module AE {
		exception AnalysisException
		{
			 /**
			 *
			 * The reason why the message was rejected by the server.
			 *
			 **/
			 string reason;
		};

		/* 调用算法返回信息结构体，例如分析图片，视频 */
		class AnalysisResult {
			string json;
			Ice::ByteSeq buffer;
			int code;
		};

		/* 调用除算法外返回信息结构体 */
		class IasiResult {
		   bool bRet;
		   string strRlt;
		};

		interface AnalysisEngine {

			/* 分析图片 */
			AnalysisResult analysisImage(string filename, Ice::ByteSeq buffer, string args) throws AnalysisException;
			
			/* 分析视频--同时送入视频文件数据 */
			AnalysisResult analysisVideo(string filename, Ice::ByteSeq buffer, string args) throws AnalysisException;
			
			/* 分析视频--仅送入视频文件地址 */
			AnalysisResult analysisVideoUrl(string videoUrl, string args) throws AnalysisException;

			/* 运行参数配置 */
			IasiResult config(string content) throws AnalysisException;

			/* 算法配置参数--覆写 */
			IasiResult algoConfig(string config) throws AnalysisException;

			/* 获取服务状态信息 */
			IasiResult status() throws AnalysisException;
			
			/* 获取qps信息 */
			IasiResult qpsInfo() throws AnalysisException;
			
			/* 授权--获取参考码、授权及清除授权、查询授权 */
			IasiResult license(string content) throws AnalysisException;
					
			/* 用于需要初始图片的算法：根据cid，增加或修改初始图片 */
			IasiResult updateInitImage(string cid, string filename, Ice::ByteSeq buffer) throws AnalysisException;
			
			/* 用于需要初始图片的算法：删除初始图片， cid为delete时表示清除所有 */
			IasiResult deleteInitImage(string cid) throws AnalysisException;
			
			/* 用于'cidPredictor'工作模式，根据cid，删除检测器实例，cid为delete时表示清除所有 */
			IasiResult deletePredictor(string cid) throws AnalysisException;
		};

		/*
		** 函数调用顺序
		[config]
		(license)
		[updateInitImage] [deleteInitImage]
		loop of ([analysisImage][analysisVideo][analysisVideoUrl])
		[deletePredictor]
		...
		
		**
		*/
	};


# 算法分析
## 图片分析
### 原型
AnalysisResult analysisImage(string filename, Ice::ByteSeq buffer, string args) throws AnalysisException;

### 功能
提供基于图片为输入源的算法分析

### 参数
* filename:图片文件名，暂时不用，保留
* buffer:图片文件原始数据
* args:参数项，例如感兴趣区域，cid等信息

### 返回值
调用成功返回AnalysisResult，其中

* code:返回值，0表示成功，其它表示失败
* result:code为0时，表示算法输出的json数据，例如

		{
		    "alert_flag": 1,
		    "alert_num": 2,
		    "alert_info": [
		        {
		            "alert_class": "garbage",
		            "x": 871,
		            "y": 531,
		            "width": 38,
		            "height": 30
		        },
		        {
		            "alert_class": "bamboo pole",
		            "x": 871,
		            "y": 531,
		            "width": 38,
		            "height": 30
		        }
		    ]
		} 

* result:code为非0时，表示具体错误的消息，例如`no authorization`
* buffer:code为0时，表示算法输出的图片数据，jpg格式
* 是否返回`result`或`buffer`，由本地配置文件`local_conf.json`：`returnValue`选项配置，默认只返回result

## 小视频分析
### 原型
AnalysisResult analysisVideo(string filename, Ice::ByteSeq buffer, string args) throws AnalysisException;

### 功能
提供基于小视频为输入源的算法分析

### 参数
* filename:视频文件名，建议只传文件名，内部仅文件扩展名有用
* buffer:视频文件原始数据
* args:参数项，例如感兴趣区域，cid等信息

### 返回值
调用成功返回AnalysisResult，其中

* code:返回值，0表示成功，其它表示失败
* result:同图片分析接口
* buffer:算法输出的视频数据，视频格式统一为mp4（x264编码）
* 是否返回`result`或`buffer`，由本地配置文件`local_conf.json`：`returnValue`选项配置，默认只返回result

## 小视频分析--仅送入视频文件地址
### 原型
AnalysisResult analysisVideoUrl(string videoUrl, string args) throws AnalysisException;

### 功能
提供基于小视频为输入源的算法分析，仅需要提供视频输入源url地址

### 参数
* videoUrl:视频源url地址
* args:参数项，例如感兴趣区域，cid等信息

### 返回值
调用成功返回AnalysisResult，其中

* code:返回值，0表示成功，其它表示失败
* result:同图片分析接口
* buffer:算法输出的视频数据，视频格式统一为mp4（x264编码）
* 是否返回`result`或`buffer`，由本地配置文件`local_conf.json`：`returnValue`选项配置，默认只返回result

# 参数设置
## 运行参数设置
### 原型
IasiResult config(string content) throws AnalysisException;

### 功能
设置运行参数并立即生效

### 参数
* content:运行参数，json格式数据，详见`README.md`:`运行参数格式`
* 示例

		{
			"workMode": "cidPredictor",
			"returnValue": "json & buffer"
		}
		
	* workMode: 工作模式，提供`simplePredictor`,`cidPredictor`,默认`simplePredictor`
		1. simplePredictor:仅开启一个检测器实例，该实例支持不同场景的分析；
		2. cidPredictor:不同的场景需要创建不同的实例来分析，其中cid是场景唯一标识；
	* returnValue:算法返回内容选择，提供`json`,`buffer`,`json & buffer`,默认`json`
		1. json:只返回json数据；
		2. buffer:只返回图片或视频数据；
		3. json & buffer:同时返回json和图片或视频数据；

### 返回值
IasiResult，其中

* bRet:true表示成功，false表示失败
* strRlt:bRet为true时，表示成功信息，例如

		{"err_code":0,"err_msg":"succeed"}

* strRlt:bRet为false时，* strRlt:bRet为true时，表示成功信息，例如

		{"err_code":-1,"err_msg":"json format or data error"}	

## 算法参数设置
### 原型
IasiResult algoConfig(string config) throws AnalysisException;

### 功能
设置算法配置参数并立即生效

先覆写算法配置文件（参数化，详见本地配置文件`local_conf.json:algoConf`选项），默认是`/usr/local/ev_sdk/model/algo_config.json`。

释放先前创建的检测器实例（如果存在），再创建新的检测器实(暂时不创建)。

### 参数
* config:算法配置参数，每个算法配置参数可能有所不同，由具体算法为准
* 示例
	
		{
			"draw_roi_area":1,
		    "draw_result":1,
			"show_result":0,
			"gpu_id":0,
			"threshold_value":0.5
		}	

	* draw_roi_area:是否绘制感兴趣区域，默认为1
	* draw_result:是否绘制检测结果信息，默认为1
	* show_result:实时显示算法分析图片，默认为0
	* gpu_id:gpu序号，仅对gpu算法有效，默认为0
	* threshold_value:阈值，默认为0.5

### 返回值
IasiResult，其中

* bRet:true表示成功，false表示失败
* strRlt:bRet为true时，表示成功信息，例如

		{"err_code":0,"err_msg":"succeed"}

* strRlt:bRet为false时，* strRlt:bRet为true时，表示成功信息，例如

		{"err_code":-1,"err_msg":"json format or data error"}	

# 状态查询
## 服务状态查询
### 原型
IasiResult status() throws AnalysisException;

### 功能
获取ias当前运行状态信息

### 参数
无参

### 返回值
函数调用后返回IasiResult。其中bRet表示成功与否，strRlt表示具体信息。

* bRet表示成功时，strRlt表示运行状态信息，json格式，例如

		{
		    "whether_authorized": true,
		    "license_data": {
		        "license": "b52f92d8ad261f16e8cafe2a2f6f9589d2f8c77533b92c0f644cf1058557e52a128fe369318f3af5bf6bf229f70bf48820df293dc7dbaf5431e02963e5e3b942febe6ca45de5bee2c1080d91467cdcedfa55555e47bc4955ac3d4e2cbdf6312ec0831a26f1d100f1921576a195aa1666a078ccf6515b40b4060cc08369485532",
		        "version": 7
		    },
		    "run_config": {
		        "workMode": "simplePredictor",
		        "returnValue": "json & buffer"
		    },
		    "whether_created_predictor": false,
		    "predictor_size": 0
		}

	* whether_authorized:是否授权，通过授权才有license_data信息
	* license_data:授权的相关信息，是个json对象
	* run_config:运行参数，是个json对象，详见`README.md`:`运行参数`
	* whether_created_predictor:是否创建了检测器实例，没触发调用时为0，一直创建成功为1，有创建失败为-1
	* predictor_size:检测器实例数

	**备注**

	* 存活判断:通信线程即工作线程，函数有正常返回即可判定是活的
	* 就绪判断:在授权通过的基础上，再判断(whether_created_predictor != -1)
	* 若(whether_created_predictor == -1 && predictor_size > 0)，表示有部分检测器创建失败，用在`cidPredictor`模式下
	
* bRet表示失败时，strRlt表示具体的失败信息（暂时不会失败返回）

## qps信息查询
### 原型
IasiResult qpsInfo() throws AnalysisException;

### 功能
获取qps相关信息，包括授权中配置的qps，及实际运行的qps（一秒内可处理的帧数）

### 参数
无参

### 返回值
函数调用后，返回VasiResult。其中bRet表示成功与否，strRlt表示具体信息

* bRet表示成功时，strRlt表示运行状态信息，json格式，例如

        {
            "auth_qps": 5.00,
            "real_qps": 16.15
        }

	* auth_qps:授权时的qps，没有授权为-1，授权无qps为0，其它为授权的qps值
	* real_qps:实际部署时qps值，动态计算取得（最近10次实际qps的平均值），没跑过算法时为0.00
	 
* bRet表示失败时，strRlt表示具体的失败信息（暂时不会失败返回）

# 授权管理
### 原型
VasiResult license(string content) throws AnalysisException

### 功能
授权管理，提供四个功能，分别是获取参考码，更改授权信息，查询授权信息，清除授权信息

### 参数
* content:请求内容，不同的功能请求内容有所不同

### 返回值
函数调用后，返回IasiResult。其中bRet表示成功与否，strRlt表示具体信息

* bRet表示成功时，strRlt不同的功能返回信息有所不同
* bRet表示失败时，strRlt表示具体的失败信息

## 获取参考码
* 请求
 * 示例

			｛
				"function": "get_reference",
				"isNetworking": 0
			｝

		* function:固定为`get_reference`
		* isNetworking:是否请求联网校验的参考码，1表示是，其它表示否，默认否，可选参数 
	
* 返回
 * 成功，示例 

			{
    			"version": 7,
    			"reference": "4ecf97189dfb9d94df43d9d14fe754ebf2707c614a50a09d5eed8ea953656695",
    			"disk_serial": "S3YLNX0K533123P",
    			"mac": "02:42:ac:11:00:0d"
			}

		* version:版本号
		* reference:参考码
		* 其它信息（版本不同也有所不同）

## 修改授权信息
* 请求
 * 示例

			{
				"function": "update_license",
				"version": 7,
				"license": "b52f92d8ad261f16e8cafe2a2f6f9589d2f8c77533b92c0f644cf1058557e52a128fe369318f3af5bf6bf229f70bf48820df293dc7dbaf5431e02963e5e3b942febe6ca45de5bee2c1080d91467cdcedfa55555e47bc4955ac3d4e2cbdf6312ec0831a26f1d100f1921576a195aa1666a078ccf6515b40b4060cc08369485532",
				"activation": "RDVG4RDVGFPC99993EA19F8334F667714CC5168D39BC3B0B052C2961F506AAAA"
			}

		* function:固定为`update_license`
		* license:授权码
		* url:联网校验服务器地址(http服务)，可选参数
		* activation:激活码，可选参数
		* timestamp:过期时间，可选参数
		* qps:最大请求量，可选参数
		* version:版本号
	
* 返回
 * 成功，示例

			{
			    "err_code": 0,
			    "err_msg": "succeed"
			}

## 查询授权信息
* 请求
 * 示例

			｛
				"function": "query_license"
			｝

			* function:固定为`query_license`
	
* 返回
 * 成功，示例 

			{
			    "license": "b52f92d8ad261f16e8cafe2a2f6f9589d2f8c77533b92c0f644cf1058557e52a128fe369318f3af5bf6bf229f70bf48820df293dc7dbaf5431e02963e5e3b942febe6ca45de5bee2c1080d91467cdcedfa55555e47bc4955ac3d4e2cbdf6312ec0831a26f1d100f1921576a195aa1666a078ccf6515b40b4060cc08369485532",
			    "version": 7
			}

		* license:授权码
		* activation:激活码
		* version:版本号

## 清除授权信息
* 请求
 * 示例

			{
				"function": "update_license"
			}

			* function:固定为`update_license`
			* 无license相关信息
	
* 返回
 * 成功，示例 

			{
			    "err_code": 0,
			    "err_msg": "succeed"
			}

# 初始图片
* 有些算法工作时需要预先送入场景初始图片，用于分析对比，例如消防通道检测算法
* 实现方案：给每个场景(cid)提供一张初始图片(jpg)，并存放在`/usr/local/ev_sdk/contrastdata`目录，调用算法的创建检测器方法时，会装载该目录下所有cid命名的jpg文件列表
* 为给上层提供增改、删初始图片的功能，ias提供`updateInitImage`,`deleteInitImage`两个方法

## 增改初始图片
### 原型
IasiResult updateInitImage(string cid, string filename, Ice::ByteSeq buffer) throws AnalysisException;

### 功能
根据cid增加或修改初始图片

### 参数
* cid:摄像头ID
* filename:图片文件名，仅文件名，但包括扩展名
* buffer:图片文件原始数据

### 返回值
IasiResult，其中

* bRet:返回值，true表示成功，false表示失败
* strRlt:返回成功或其它错误信息

## 删除初始图片
### 原型
IasiResult deleteInitImage(string cid) throws AnalysisException;

### 功能
根据cid删除初始图片，其中cid为`delete`表示删除全部初始图片

### 参数
* cid:摄像头ID

### 返回值
IasiResult，其中

* bRet:返回值，true表示成功，false表示失败
* strRlt:返回成功或其它错误信息

# 删除检测器实例
### 原型
IasiResult deletePredictor(string cid) throws AnalysisException;

### 功能
仅在`cidPredictor`工作模式下有效，用于删除指定cid的检测器实例，以节省有限的硬件资源，例如内存及gpu内存

### 参数
* cid:摄像头ID，其中cid为`delete`表示删除全部检测器实例

### 返回值
IasiResult，其中

* bRet:返回值，true表示成功，false表示失败
* strRlt:返回成功或其它错误信息

# 测试工具
在安装目录下，运行`./testIas -h`，输出帮助信息如下

	---------------------------------
	usage:
	  -h  --help        show help information
	  -s  --server      ICE server host. default: 127.0.0.1
	  -p  --port        ICE server port. default: 10000
	  -f  --function    ICE function interface, for example:
	                    1.analysisImage
	                    2.analysisVideo
	                    3.analysisVideoUrl
	                    4.config
	                    5.algoConfig
	                    6.status
	                    7.qpsInfo
	                    8.license
	                    9.updateInitImage
	                    10.deleteInitImage
	                    11.deletePredictor
	  -c  --content     1&2:media_file;3:videoUrl;4&5&8&9:json_file;10&11:cid(delete:all)
	  -a  --args        for example roi
	
	---------------------------------


 例如

    ./testIas -f 1 -c test.jpg
	./testIas -f 2 -c test.mp4
	./testIas -f 3 -c video_url
	./testIas -f 4 -c config_simplePredictor.sample
	./testIas -f 4 -c config_cidPredictor.sample
	./testIas -f 5 -c algo_config.sample
	./testIas -f 6 
	./testIas -f 7
	./testVas -f 8 -c license_get_reference.sample
	./testVas -f 8 -c license_query_license.sample
	./testVas -f 9 -c updateInitImage.sample
	./testVas -f 10 -c 123456
	./testVas -f 11 -c 123456

---